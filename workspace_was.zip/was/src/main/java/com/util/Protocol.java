package com.util;

public class Protocol {
	public static final String PART = "MyPunchDrunkBoxer";
}
