package com.vo;

public class ErpEmpVO {
	
 private String empno         ="";
 private String emp_name      ="";
 private String resident_no   ="";
 private String emp_hp        ="";
 private String emp_addr      ="";
 private String emp_indate    ="";
 private String emp_outdate   ="";
 private String dept_code     ="";
 private String rank_code     ="";
 private String emp_pw        ="";
 private String msg			  ="";
public String getEmpno() {
	return empno;
}
public void setEmpno(String empno) {
	this.empno = empno;
}
public String getEmp_name() {
	return emp_name;
}
public void setEmp_name(String emp_name) {
	this.emp_name = emp_name;
}
public String getResident_no() {
	return resident_no;
}
public void setResident_no(String resident_no) {
	this.resident_no = resident_no;
}
public String getEmp_hp() {
	return emp_hp;
}
public void setEmp_hp(String emp_hp) {
	this.emp_hp = emp_hp;
}
public String getEmp_addr() {
	return emp_addr;
}
public void setEmp_addr(String emp_addr) {
	this.emp_addr = emp_addr;
}
public String getEmp_indate() {
	return emp_indate;
}
public void setEmp_indate(String emp_indate) {
	this.emp_indate = emp_indate;
}
public String getEmp_outdate() {
	return emp_outdate;
}
public void setEmp_outdate(String emp_outdate) {
	this.emp_outdate = emp_outdate;
}
public String getDept_code() {
	return dept_code;
}
public void setDept_code(String dept_code) {
	this.dept_code = dept_code;
}
public String getRank_code() {
	return rank_code;
}
public void setRank_code(String rank_code) {
	this.rank_code = rank_code;
}
public String getEmp_pw() {
	return emp_pw;
}
public void setEmp_pw(String emp_pw) {
	this.emp_pw = emp_pw;
}
public String getMsg() {
	return msg;
}
public void setMsg(String msg) {
	this.msg = msg;
}
}
