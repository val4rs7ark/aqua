package com.was.erp;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/draft*")
public class DraftController {
	Logger logger = LoggerFactory.getLogger(DraftController.class);
	@Autowired(required=false)
	DraftLogic draftLogic = null;
	
	@GetMapping("/draftMain")
	public String draftMain(@RequestParam Map<String,Object> pMap) {
//		logger.info(pMap.get("db_title").toString());
//		logger.info(pMap.get("ir1").toString());
//		logger.info("hd_title:"+pMap.get("hd_title").toString());
		return "/draft/draft_main";
	}
	
	@GetMapping("/draft_basic")
	public String draft_basic(@RequestParam Map<String,Object> pMap) {
//		logger.info(pMap.get("db_title").toString());
//		logger.info(pMap.get("ir1").toString());
//		logger.info("hd_title:"+pMap.get("hd_title").toString());
		return "/draft/draft_basic";
	}
	
	@PostMapping("/draftAdd")
	public void draftAdd(@RequestParam Map<String,Object> pMap) {
		logger.info(pMap.get("db_title").toString());
		logger.info(pMap.get("ir1").toString());
		draftLogic.draftAdd(pMap);
	}
	
	@PostMapping("/general_dBChoice")
	public String dBChoice(@RequestParam Map<String,Object> pMap) {
		logger.info("general_dBChoice 호출 성공");
		return "/draft/choice";
	}
	//선택창 눌르면 켜지는 모달창
	@PostMapping("/draft_SubDraft")
	public String dBsubDraft(@RequestParam Map<String,Object> pMap) {
		logger.info("draft_SubDraft 호출 성공");
		return "/draft/subDraft";
	}

	//기안서 선택창에서 사원을 선택을 했을 경우
	@GetMapping("/draft_selectEmp")
	public String draft_selectEmp(@RequestParam Map<String,Object> pMap,Model model) {
		logger.info("draft_selectEmp호출 성공");
		List<Map<String,Object>> result_List = draftLogic.draft_selectEmp(pMap);
		model.addAttribute("result_List",result_List);
		return "general/ajax/select_teamName";
	}
	//기안서 제거창에서 사원을 선택을 했을 경우
	@GetMapping("/draft_deleteEmp")
	public String draft_deleteEmp(@RequestParam Map<String,Object> pMap,Model model) {
		logger.info("draft_deleteEmp호출 성공");
		List<Map<String,Object>> result_List = draftLogic.draft_deleteEmp(pMap);
		model.addAttribute("result_List",result_List);
		return "general/ajax/lastbox_empName";
	}
}
